<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resources | Future Hub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            background: #f4f6fa;
            color: #1a1a1a;
        }
        header {
            background: #1a1a2e;
            color: white;
            padding: 1em 2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5em;
            font-weight: bold;
            color: white;
        }
        nav a, nav span {
            margin-left: 1em;
            color: white;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        main {
            max-width: 1100px;
            margin: 3em auto;
            padding: 2em;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.05);
        }
        h1 {
            font-size: 2.3em;
            margin-bottom: 0.3em;
        }
        p {
            font-size: 1.1em;
            margin-bottom: 2em;
            color: #555;
        }
        .resources-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2em;
        }
        .resource-card {
            background: #f9fafc;
            padding: 1.5em;
            border-radius: 10px;
            border-left: 5px solid #ffd700;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
            transition: transform 0.2s ease;
        }
        .resource-card:hover {
            transform: translateY(-5px);
        }
        .resource-card h3 {
            margin: 0 0 0.5em;
            font-size: 1.3em;
            color: #1a1a2e;
        }
        .resource-card p {
            margin: 0 0 1em;
            font-size: 1em;
            color: #444;
        }
        .resource-card a {
            text-decoration: none;
            font-weight: bold;
            color: #1a1a2e;
            background: #ffd700;
            padding: 0.5em 1em;
            border-radius: 6px;
            transition: background 0.3s ease;
        }
        .resource-card a:hover {
            background: #e6c200;
        }
        footer {
            text-align: center;
            padding: 2em;
            margin-top: 4em;
            background: #1a1a2e;
            color: #ccc;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Future Hub</div>
    <nav>
        <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
        <a href="student_dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>
    <h1>🔗 Curated Learning Resources</h1>
    <p>Explore top-notch tools and platforms to supercharge your learning journey.</p>

    <div class="resources-grid">
        <div class="resource-card">
            <h3>FreeCodeCamp</h3>
            <p>Master web development with interactive lessons and hands-on projects.</p>
            <a href="https://www.freecodecamp.org" target="_blank">Visit Site →</a>
        </div>
        <div class="resource-card">
            <h3>Khan Academy</h3>
            <p>Deepen your understanding of math, science, computer science, and more.</p>
            <a href="https://www.khanacademy.org" target="_blank">Visit Site →</a>
        </div>
        <div class="resource-card">
            <h3>roadmap.sh</h3>
            <p>Visual roadmaps to navigate career paths in software development.</p>
            <a href="https://roadmap.sh" target="_blank">Visit Site →</a>
        </div>
        <div class="resource-card">
            <h3>Coursera</h3>
            <p>University-level courses from top institutions with certification options.</p>
            <a href="https://www.coursera.org" target="_blank">Visit Site →</a>
        </div>
        <div class="resource-card">
            <h3>GeeksForGeeks</h3>
            <p>Articles, tutorials, and coding questions for interview and exam prep.</p>
            <a href="https://www.geeksforgeeks.org" target="_blank">Visit Site →</a>
        </div>
    </div>
</main>

<footer>
    &copy; <?= date('Y') ?> Future Hub. All rights reserved.
</footer>
</body>
</html>