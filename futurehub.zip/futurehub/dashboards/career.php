<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Career Guidance | Future Hub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css" />
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: #f5f6fa;
            color: #1a1a1a;
        }
        header {
            background: #1a1a2e;
            color: white;
            padding: 1em 2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5em;
            font-weight: bold;
            color: white;
        }
        nav a, nav span {
            margin-left: 1em;
            color: white;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        main {
            max-width: 1100px;
            margin: 2em auto;
            padding: 0 2em;
        }
        h1 {
            font-size: 2.5em;
            margin-bottom: 0.3em;
        }
        p {
            font-size: 1.1em;
            color: #555;
            margin-bottom: 2em;
        }

        .career-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 1.5em;
            margin-bottom: 3em;
        }

        .career-card {
            background: white;
            border-radius: 10px;
            padding: 1.5em;
            box-shadow: 0 4px 10px rgba(0,0,0,0.06);
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .career-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .career-card h3 {
            margin-bottom: 0.5em;
            color: #1a1a2e;
            font-size: 1.2em;
        }

        .career-card p {
            color: #666;
            font-size: 0.95em;
        }

        blockquote {
            background: #fff;
            padding: 1.2em;
            border-left: 5px solid #ffd700;
            margin-bottom: 1.5em;
            font-style: italic;
            color: #333;
            border-radius: 6px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        }

        .mentor-section {
            background: #fff;
            padding: 2em;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.07);
            text-align: center;
        }

        .mentor-section a {
            display: inline-block;
            margin-top: 1em;
            padding: 0.75em 1.5em;
            background: #ffd700;
            color: #1a1a2e;
            text-decoration: none;
            font-weight: bold;
            border-radius: 8px;
            transition: background 0.3s;
        }

        .mentor-section a:hover {
            background: #e6c200;
        }

        footer {
            text-align: center;
            padding: 2em;
            background: #1a1a2e;
            color: #ccc;
            margin-top: 4em;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Future Hub</div>
    <nav>
        <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
        <a href="student_dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>
    <h1>💼 Career Guidance & Mentorship</h1>
    <p>Explore real-world career paths, actionable advice, and upcoming mentorship opportunities.</p>

    <section>
        <h2>📌 Popular Career Tracks</h2>
        <div class="career-grid">
            <div class="career-card">
                <h3>Frontend Developer</h3>
                <p>Build sleek, interactive websites using HTML, CSS, and JavaScript frameworks like React.</p>
            </div>
            <div class="career-card">
                <h3>Backend Engineer</h3>
                <p>Design scalable systems using Node.js, Python, or Java. Manage databases and APIs.</p>
            </div>
            <div class="career-card">
                <h3>AI/ML Specialist</h3>
                <p>Analyze data and build intelligent systems with Python, TensorFlow, and machine learning tools.</p>
            </div>
            <div class="career-card">
                <h3>Cybersecurity Analyst</h3>
                <p>Protect digital assets, analyze threats, and secure systems in a growing security-first world.</p>
            </div>
            <div class="career-card">
                <h3>Product Manager</h3>
                <p>Lead development teams, define product vision, and create impactful digital solutions.</p>
            </div>
        </div>

        <h2>🎤 Expert Tips</h2>
        <blockquote>“Focus on mastering the fundamentals before chasing trends.” – Tech Lead, Google</blockquote>
        <blockquote>“Your first job won’t define you. Learn, fail, and grow.” – Developer Advocate, Microsoft</blockquote>
    </section>

    <section class="mentor-section">
        <h2>📞 Book a 1:1 with a Mentor</h2>
        <p>Personalised guidance from professionals in your dream field.</p>
        <a href="#">Find a mentor now →</a>
    </section>
</main>

<footer>
    &copy; <?= date('Y') ?> Future Hub. All rights reserved.
</footer>
</body>
</html>