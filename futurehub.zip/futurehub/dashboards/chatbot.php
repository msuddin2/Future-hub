<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Roadmap Bot | Future Hub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background-color: #f4f6fa;
            color: #1a1a1a;
        }
        header {
            background: #1a1a2e;
            color: white;
            padding: 1em 2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5em;
            font-weight: bold;
            color: white;
        }
        nav a, nav span {
            margin-left: 1em;
            color: white;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        main {
            max-width: 900px;
            margin: 3em auto;
            padding: 2em;
            background: white;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.06);
        }
        h1 {
            font-size: 2.4em;
            margin-bottom: 0.3em;
        }
        p {
            font-size: 1.1em;
            color: #555;
        }
        form {
            margin-top: 2em;
        }
        label {
            font-weight: 600;
            display: block;
            margin-bottom: 0.5em;
            color: #333;
        }
        input[type="text"] {
            width: 100%;
            padding: 1em;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin-bottom: 1.5em;
        }
        button.btn {
            background-color: #ffd700;
            border: none;
            color: #1a1a2e;
            padding: 0.75em 1.5em;
            font-size: 1em;
            font-weight: bold;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        button.btn:hover {
            background-color: #e6c200;
        }

        #roadmap {
            margin-top: 3em;
            padding: 2em;
            background: #f9fafc;
            border-left: 5px solid #ffd700;
            border-radius: 8px;
            font-size: 1.05em;
            line-height: 1.6em;
            color: #333;
        }

        #chat-icon {
            font-size: 2em;
            animation: pulse 1.8s infinite ease-in-out;
        }

        @keyframes pulse {
            0% { transform: scale(1); opacity: 0.9; }
            50% { transform: scale(1.08); opacity: 1; }
            100% { transform: scale(1); opacity: 0.9; }
        }

        footer {
            text-align: center;
            padding: 2em;
            margin-top: 4em;
            background: #1a1a2e;
            color: #ccc;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Future Hub</div>
    <nav>
        <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
        <a href="student_dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>
    <h1 id="chat-icon">🤖 Personalised Roadmap Assistant</h1>
    <p>Need a plan to reach your learning goals? Just tell us your ambition, and we’ll guide your steps.</p>

    <form method="POST" action="#">
        <label for="goal">What's your learning goal?</label>
        <input type="text" name="goal" id="goal" placeholder="e.g. Become a frontend developer" required>
        <button class="btn">Generate Roadmap</button>
    </form>

    <div id="roadmap">
        <p><em>Enter your goals and your personalised roadmap will appear here.</em></p>
    </div>
</main>

<footer>
    &copy; <?= date('Y') ?> Future Hub. All rights reserved.
</footer>
</body>
</html>