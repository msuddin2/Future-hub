<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Blogs | Future Hub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css" />
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: #f9f9fb;
            color: #1a1a1a;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #1a1a2e;
            padding: 1em 2em;
            color: white;
        }
        .logo {
            font-size: 1.5em;
            font-weight: 800;
            color: white;
        }
        nav a, nav span {
            color: white;
            margin-left: 1em;
            text-decoration: none;
            font-weight: 500;
        }
        nav a:hover {
            text-decoration: underline;
        }
        main {
            max-width: 1200px;
            margin: 2em auto;
            padding: 0 2em;
        }
        main h1 {
            font-size: 2.5em;
            margin-bottom: 0.2em;
        }
        main p {
            color: #555;
            font-size: 1.1em;
            margin-bottom: 2em;
        }

        .blog-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2em;
        }

        .blog-card {
            background: white;
            border-radius: 12px;
            padding: 1.5em;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
        }

        .blog-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
        }

        .blog-card h2 {
            font-size: 1.4em;
            margin-bottom: 0.5em;
            color: #1a1a2e;
        }

        .blog-card p {
            font-size: 1em;
            color: #444;
            margin-bottom: 1em;
        }

        .blog-card a {
            text-decoration: none;
            color: #1a1a2e;
            font-weight: 600;
            transition: color 0.3s ease;
        }

        .blog-card a:hover {
            color: #1a1a2e;
        }

        footer {
            text-align: center;
            padding: 2em 0;
            background: #1a1a2e;
            color: #ccc;
            margin-top: 4em;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">Future Hub</div>
        <nav>
            <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
            <a href="student_dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <main>
        <h1>📚 Explore Educational Blogs</h1>
        <p>Curated articles to keep you inspired, informed, and ahead of the curve.</p>

        <section class="blog-grid">
            <div class="blog-card">
                <h2>Top 5 Habits of Successful Students</h2>
                <p>Learn time management, focus strategies, and how to avoid burnout from top performers.</p>
                <a href="#">Read More →</a>
            </div>
            <div class="blog-card">
                <h2>Latest Trends in Tech & AI</h2>
                <p>Stay ahead with updates in AI, machine learning, and tech innovation.</p>
                <a href="#">Read More →</a>
            </div>
            <div class="blog-card">
                <h2>How to Stay Motivated During Exams</h2>
                <p>Real tips from real students. Beat procrastination and keep your momentum high.</p>
                <a href="#">Read More →</a>
            </div>
            <div class="blog-card">
                <h2>Balancing Study and Life</h2>
                <p>Achieve harmony with strategies that support both academic success and personal well-being.</p>
                <a href="#">Read More →</a>
            </div>
            <div class="blog-card">
                <h2>Building Your Personal Brand Online</h2>
                <p>Learn how to create a professional digital presence even before graduation.</p>
                <a href="#">Read More →</a>
            </div>
        </section>
    </main>

    <footer>