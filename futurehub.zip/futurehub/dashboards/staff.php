<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'staff') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Staff Dashboard</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <header>
    <div class="logo">Future Hub</div>
    <nav>
      <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
      <a href="../php/logout.php">Logout</a>
    </nav>
  </header>

  <main style="padding: 2em;">
    <h2>School Staff Dashboard</h2>
    <ul style="list-style-type: none; padding: 0;">
      <li><a href="#">🎓 Assign Courses to Students</a></li>
      <li><a href="#">📋 View Course Progress</a></li>
      <li><a href="#">🧾 Review Course Material</a></li>
      <li><a href="#">👥 Manage Students</a></li>
    </ul>
  </main>
</body>
</html>