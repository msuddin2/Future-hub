<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tutorials | Future Hub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            background: #f4f6fa;
            color: #1a1a1a;
        }
        header {
            background: #1a1a2e;
            color: white;
            padding: 1em 2em;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo {
            font-size: 1.5em;
            font-weight: bold;
            color: white;
        }
        nav a, nav span {
            margin-left: 1em;
            color: white;
            text-decoration: none;
        }
        nav a:hover {
            text-decoration: underline;
        }
        main {
            max-width: 1100px;
            margin: 3em auto;
            padding: 2em;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.05);
        }
        h1 {
            font-size: 2.3em;
            margin-bottom: 0.3em;
        }
        p {
            font-size: 1.1em;
            margin-bottom: 2em;
            color: #555;
        }
        .tutorials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2em;
        }
        .tutorial-card {
            background: #f9fafc;
            padding: 1.5em;
            border-radius: 10px;
            border-left: 5px solid #00c897;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.03);
            transition: transform 0.2s ease;
        }
        .tutorial-card:hover {
            transform: translateY(-5px);
        }
        .tutorial-card h2 {
            margin: 0 0 0.5em;
            font-size: 1.3em;
            color: #1a1a2e;
        }
        .tutorial-card p {
            margin: 0 0 1em;
            font-size: 1em;
            color: #444;
        }
        .tutorial-card a {
            text-decoration: none;
            font-weight: bold;
            color: white;
            background: #00c897;
            padding: 0.5em 1em;
            border-radius: 6px;
            transition: background 0.3s ease;
            display: inline-block;
        }
        .tutorial-card a:hover {
            background: #00b184;
        }
        footer {
            text-align: center;
            padding: 2em;
            margin-top: 4em;
            background: #1a1a2e;
            color: #ccc;
        }
    </style>
</head>
<body>
<header>
    <div class="logo">Future Hub</div>
    <nav>
        <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
        <a href="student_dashboard.php">Dashboard</a>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>
    <h1>🎓 How-To Tutorials</h1>
    <p>Step-by-step guides to help you master essential skills efficiently and confidently.</p>

    <div class="tutorials-grid">
        <div class="tutorial-card">
            <h2>📘 HTML & CSS Basics</h2>
            <p>Learn to structure and style your first website with ease.</p>
            <a href="#">Start Tutorial →</a>
        </div>
        <div class="tutorial-card">
            <h2>💾 Git & GitHub for Beginners</h2>
            <p>Master version control, collaboration, and open source workflows.</p>
            <a href="#">Start Tutorial →</a>
        </div>
        <div class="tutorial-card">
            <h2>🧠 Python Crash Course</h2>
            <p>Build a strong foundation in one of the most in-demand programming languages.</p>
            <a href="#">Start Tutorial →</a>
        </div>
    </div>
</main>

<footer>
    &copy; <?= date('Y') ?> Future Hub. All rights reserved.
</footer>
</body>
</html>