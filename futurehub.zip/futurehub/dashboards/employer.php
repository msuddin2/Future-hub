<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'employer') {
    header("Location: ../login.html");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Employer Dashboard</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <header>
    <div class="logo">Future Hub</div>
    <nav>
      <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
      <a href="../php/logout.php">Logout</a>
    </nav>
  </header>

  <main style="padding: 2em;">
    <h2>Employer Dashboard</h2>
    <ul style="list-style-type: none; padding: 0;">
      <li><a href="../php/add_course.php">📝 Add New Courses</a></li>
      <li><a href="#">📂 Edit/Delete Existing Courses</a></li>
      <li><a href="#">💼 Publish Job Listings</a></li>
      <li><a href="#">📊 View Course Engagement</a></li>
    </ul>
  </main>
</body>
</html>