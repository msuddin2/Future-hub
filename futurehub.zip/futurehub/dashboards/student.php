<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
  header("Location: ../login.html");
  exit();
}

$conn = new mysqli("localhost", "root", "", "futurehub");
$courses = $conn->query("SELECT * FROM courses");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="../css/style.css" />
  <style>
    .course-card {
      background: #fff;
      padding: 1.5em;
      border-radius: 16px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      margin: 1em;
      flex: 1 1 30%;
    }
    .courses-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-between;
      padding: 2em;
    }
    .progress-bar {
      height: 10px;
      border-radius: 5px;
      background-color: #e0e0e0;
      margin-top: 10px;
    }
    .progress-fill {
      height: 100%;
      background-color: #3b82f6;
      border-radius: 5px;
      width: 0%;
      transition: width 0.3s;
    }
nav {
    display: flex;
    align-items: center;
    gap: 1em;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropbtn {
    background-color: #3498db;
    color: white;
    padding: 10px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    border-radius: 4px;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: white;
    min-width: 200px;
    box-shadow: 0px 8px 16px rgba(0,0,0,0.2);
    z-index: 1;
    border-radius: 4px;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {
    background-color: #f1f1f1;
}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #2980b9;
}

  </style>
</head>
<body>
<header>
    <div class="logo">Future Hub</div>
    <nav>
        <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
        <div class="dropdown">
            <button class="dropbtn">Explore ▼</button>
            <div class="dropdown-content">
                <a href="blogs.php">📚 Blogs</a>
                <a href="tutorials.php">🎓 Tutorials</a>
                <a href="resources.php">🔗 Resources</a>
                <a href="chatbot.php">🤖 Roadmap Bot</a>
                <a href="career.php">💼 Career Guidance</a>
            </div>
        </div>
        <a href="logout.php">Logout</a>
    </nav>
</header>

<main>
  <h2 style="padding-left: 2em;">📘 My Courses</h2>
  <div class="courses-container">
    <?php while ($course = $courses->fetch_assoc()) : ?>
      <div class="course-card">
        <h3><?= htmlspecialchars($course['title']) ?></h3>
        <p><?= htmlspecialchars($course['description']) ?></p>
        <div class="progress-bar">
          <div class="progress-fill" data-course="<?= $course['id'] ?>"></div>
        </div>
        <a href="../php/course_view.php?course=<?= $course['id'] ?>" class="btn" style="margin-top: 1em; display: inline-block;">Start Course</a>
      </div>
    <?php endwhile; ?>
  </div>
</main>

<script>
  // Auto-fill progress from backend
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.progress-fill').forEach(bar => {
      const courseId = bar.dataset.course;
      fetch(`../php/fetch_progress.php?course_id=${courseId}`)
        .then(res => res.json())
        .then(data => {
          bar.style.width = `${data.progress}%`;
        });
    });
  });
</script>
</body>
</html>