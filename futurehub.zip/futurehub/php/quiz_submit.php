<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: ../login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "futurehub");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = $_SESSION['username'];
$course_id = intval($_POST['course']);
$lesson_id = intval($_POST['lesson']);
$answer = $_POST['answer'];
$correct = $_POST['correct'];

// Save progress
$quiz_id_result = $conn->query("SELECT id FROM course_quizzes WHERE lesson_id = $lesson_id LIMIT 1");
$quiz_id = $quiz_id_result->fetch_assoc()['id'];

if ($answer === $correct) {
    $conn->query("INSERT IGNORE INTO quiz_progress (username, course_id, quiz_id, answer)
                  VALUES ('$username', $course_id, $quiz_id, '$answer')");
    // Redirect back to same lesson with success flag
    header("Location: course_view.php?course=$course_id&lesson=$lesson_id&result=correct");
} else {
    header("Location: course_view.php?course=$course_id&lesson=$lesson_id&result=incorrect");
}
exit();