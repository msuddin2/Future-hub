<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
    header("Location: ../login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "futurehub");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the course ID from the URL
$course_id = isset($_GET['course']) ? intval($_GET['course']) : 0;

// If a specific lesson is requested
if (isset($_GET['lesson'])) {
    $lesson_id = intval($_GET['lesson']);
} else {
    $lesson = $conn->query("SELECT id FROM course_lessons WHERE course_id = $course_id ORDER BY id ASC LIMIT 1")->fetch_assoc();
    $lesson_id = $lesson['id'];
}

// Load lesson content
$lesson = $conn->query("SELECT * FROM course_lessons WHERE id = $lesson_id")->fetch_assoc();
$quiz = $conn->query("SELECT * FROM course_quizzes WHERE lesson_id = $lesson_id")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title><?= htmlspecialchars($lesson['title']) ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="logo">Future Hub</div>
        <nav>
            <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <main style="padding: 2em;">
	<?php if (isset($_GET['result'])): ?>
    <div style="padding: 1em; border: 1px solid #ccc; background: #f9f9f9; margin-bottom: 1em;">
        <?php if ($_GET['result'] === 'correct'): ?>
            <p style="color: green;">✅ Correct answer!</p>
        <?php else: ?>
            <p style="color: red;">❌ Incorrect answer. Try again!</p>
        <?php endif; ?>
    </div>
<?php endif; ?>

        <h2><?= htmlspecialchars($lesson['title']) ?></h2>
        <p><?= nl2br(htmlspecialchars($lesson['content'])) ?></p>

        <?php if ($quiz): ?>
            <hr>
            <h3>🧠 Quick Quiz</h3>
            <form method="POST" action="quiz_submit.php">
                <p><strong><?= htmlspecialchars($quiz['question']) ?></strong></p>

                <label><input type="radio" name="answer" value="a" required> A) <?= htmlspecialchars($quiz['option_a']) ?></label><br>
                <label><input type="radio" name="answer" value="b"> B) <?= htmlspecialchars($quiz['option_b']) ?></label><br>
                <label><input type="radio" name="answer" value="c"> C) <?= htmlspecialchars($quiz['option_c']) ?></label><br>
                <label><input type="radio" name="answer" value="d"> D) <?= htmlspecialchars($quiz['option_d']) ?></label><br>

                <input type="hidden" name="correct" value="<?= $quiz['correct_option'] ?>">
                <input type="hidden" name="course" value="<?= $course_id ?>">
                <input type="hidden" name="lesson" value="<?= $lesson_id ?>">

                <br><button class="btn" type="submit">Submit Answer</button>
            </form>
        <?php else: ?>
            <p><em>No quiz available for this lesson.</em></p>
        <?php endif; ?>
    </main>
</body>
</html>