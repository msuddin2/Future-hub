<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
  header("Location: ../login.html");
  exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Career Guidance</title>
  <link rel="stylesheet" href="../css/style.css">
</head>
<body>
  <header>
    <div class="logo">Future Hub</div>
    <nav>
      <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main style="padding: 2em;">
    <h2>🎯 Career Guidance</h2>
    <p>Explore resources to help you decide your future path.</p>

    <div style="margin-top: 2em;">
      <h3>🌱 Popular Career Paths</h3>
      <ul style="list-style-type: none; padding: 0;">
        <li><strong>🩺 Healthcare:</strong> Doctor, Nurse, Therapist, EMT</li>
        <li><strong>💻 Tech:</strong> Software Developer, UI/UX Designer, Data Analyst</li>
        <li><strong>🛠️ Trades:</strong> Electrician, Plumber, Mechanic</li>
        <li><strong>🎨 Creative:</strong> Graphic Designer, Writer, Filmmaker</li>
        <li><strong>📚 Education:</strong> Teacher, School Counselor, Librarian</li>
      </ul>

      <h3 style="margin-top: 2em;">🧠 Tips for Choosing Your Path</h3>
      <ul>
        <li>Identify your strengths and interests.</li>
        <li>Talk to professionals in the field.</li>
        <li>Try internships or volunteer work.</li>
        <li>Use online career quizzes or personality tests.</li>
        <li>Discuss options with teachers or mentors.</li>
      </ul>
    </div>
  </main>
</body>
</html>