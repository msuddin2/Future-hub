<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'employer') {
    header("Location: ../login.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $created_by = $_SESSION['username'];

    $conn = new mysqli("localhost", "root", "", "futurehub");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO courses (title, description, created_by) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $title, $description, $created_by);
    $stmt->execute();

    echo "✅ Course added successfully.";
    echo '<br><a href="../dashboards/employer.php">← Back to Dashboard</a>';

    $stmt->close();
    $conn->close();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Add Course</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <header>
    <div class="logo">Future Hub</div>
    <nav>
      <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main style="padding: 2em;">
    <h2>Add New Course</h2>
    <form method="POST">
      <label>Course Title:</label><br>
      <input type="text" name="title" required><br><br>

      <label>Description:</label><br>
      <textarea name="description" rows="5" required></textarea><br><br>

      <button type="submit" class="btn">Add Course</button>
    </form>
  </main>
</body>
</html>