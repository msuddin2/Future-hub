<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'student') {
    header("Location: ../login.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "futurehub");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM courses ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Available Courses</title>
  <link rel="stylesheet" href="../css/style.css" />
</head>
<body>
  <header>
    <div class="logo">Future Hub</div>
    <nav>
      <span>Welcome, <?= htmlspecialchars($_SESSION['username']) ?> 👋</span>
      <a href="logout.php">Logout</a>
    </nav>
  </header>

  <main style="padding: 2em;">
    <h2>Available Courses</h2>
    <?php while ($row = $result->fetch_assoc()): ?>
      <div style="background: white; padding: 1em; margin-bottom: 1em; border-radius: 8px;">
        <h3><?= htmlspecialchars($row['title']) ?></h3>
        <p><?= nl2br(htmlspecialchars($row['description'])) ?></p>
        <small><i>Created by: <?= htmlspecialchars($row['created_by']) ?></i></small>
      </div>
    <?php endwhile; ?>
  </main>
</body>
</html>

<?php
$conn->close();
?>