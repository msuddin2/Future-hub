<?php
session_start();

$host = "localhost";
$dbname = "futurehub";
$db_user = "root";
$db_pass = "";

$conn = new mysqli($host, $db_user, $db_pass, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$user = $_POST['username'];
$pass = $_POST['password'];
$role = $_POST['role'];

$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ? AND role = ?");
$stmt->bind_param("sss", $user, $pass, $role);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $_SESSION['username'] = $row['username'];
    $_SESSION['role'] = $row['role'];

    if ($role == 'student') {
        header("Location: ../dashboards/student.php");
    } elseif ($role == 'staff') {
        header("Location: ../dashboards/staff.php");
    } elseif ($role == 'employer') {
        header("Location: ../dashboards/employer.php");
    }
    exit();
} else {
    echo "❌ Invalid login.";
}

$stmt->close();
$conn->close();
?>