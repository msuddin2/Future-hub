<?php
$db = new SQLite3('../data/users.db');
$db->exec("CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  password TEXT,
  role TEXT
)");
$db->exec("INSERT INTO users (username, password, role) VALUES ('alice', 'pass123', 'student')");
$db->exec("INSERT INTO users (username, password, role) VALUES ('bob', 'staffpass', 'staff')");
$db->exec("INSERT INTO users (username, password, role) VALUES ('employer1', 'jobpass', 'employer')");
echo "Setup complete.";
?>
