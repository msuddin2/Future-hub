<?php
session_start();
$conn = new mysqli("localhost", "root", "", "futurehub");

$course_id = $_GET['course_id'];
$user = $_SESSION['username'];

// For simplicity, assume progress stored as course_user_progress table
$res = $conn->query("SELECT COUNT(*) as answered FROM quiz_progress WHERE username = '$user' AND course_id = $course_id");
$answered = $res->fetch_assoc()['answered'];

$total = $conn->query("SELECT COUNT(*) as total FROM course_quizzes q 
                      JOIN course_lessons l ON q.lesson_id = l.id 
                      WHERE l.course_id = $course_id")->fetch_assoc()['total'];

$progress = ($total > 0) ? round(($answered / $total) * 100) : 0;

echo json_encode(['progress' => $progress]);