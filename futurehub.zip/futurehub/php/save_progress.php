<?php
session_start();
$conn = new mysqli("localhost", "root", "", "futurehub");

$username = $_SESSION['username'];
$course_id = $_POST['course_id'];
$quiz_id = $_POST['quiz_id'];
$answer = $_POST['answer'];

$correct = $conn->query("SELECT correct_option FROM course_quizzes WHERE id = $quiz_id")->fetch_assoc()['correct_option'];

if ($answer === $correct) {
  $conn->query("INSERT IGNORE INTO quiz_progress (username, course_id, quiz_id, answer)
                VALUES ('$username', $course_id, $quiz_id, '$answer')");
  echo "✅ Correct!";
} else {
  echo "❌ Incorrect.";
}